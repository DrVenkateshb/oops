import java.util.*;

public class StudentCollections {
    public static void main(String[] args) {

        // Step 1: Create an ArrayList to store student marks
        ArrayList<Integer> marks = new ArrayList<>();

        // Step 2: Add elements to the ArrayList
        marks.add(85);
        marks.add(72);
        marks.add(90);
        marks.add(66);
        marks.add(78);
        marks.add(100);

        // Step 3: Display original list
        System.out.println("Original Marks: " + marks);

        // Step 4: Sort the list (Ascending)
        Collections.sort(marks);
        System.out.println("Sorted Marks (Ascending): " + marks);

        // Step 5: Reverse the list (Descending)
        Collections.reverse(marks);
        System.out.println("Sorted Marks (Descending): " + marks);

        // Step 6: Find Maximum and Minimum marks
        int maxMarks = Collections.max(marks);
        int minMarks = Collections.min(marks);

        System.out.println("Highest Marks: " + maxMarks);
        System.out.println("Lowest Marks: " + minMarks);

        // Step 7: Iterate using for-each loop
        System.out.println("Marks using for-each loop:");
        for(int m : marks) {
            System.out.println(m);
        }
    }
}